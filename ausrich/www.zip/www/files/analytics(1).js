<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=7" />
<title>雅思,雅思培训学校,启德学府雅思,2011年雅思考试报名,雅思考试,雅思考试时间,雅思报名,雅思培训,启德学府,托福,托福培训学校,启  德学府托福,2011年</title>
<meta name="keywords" content="雅思,雅思培训学校,启德学府雅思,2011年雅思考试报名,雅思考试,雅思考试时间,雅思报名,雅思培训,启德学府,托福,托" />
<meta name="description" content="启德学府是权威专业的国际语言培训机构门户网站,雅思培训/托福培训/SAT培训著名品牌！常年从事雅思培训,托福培训,SAT培训及法语,德语,西班牙语等小语种语言培训及各类出国留学语言培训,教学实力雄厚,培训效果卓越,帮助不同水平学员达到雅思6分,雅思6.5分,雅思7分, 雅思单项突破,实现出国梦,享受" />
<link rel="stylesheet" type="text/css" href="http://img0.eic.org.cn/public/style/base.css"/>
<link rel="stylesheet" type="text/css" href="http://img0.eic.org.cn/public/style/master.css"/>
<link rel="stylesheet" type="text/css" href="http://img0.eic.org.cn/public/style/right.css"/>
</head>
<body>
<!-- header start -->
<script language="javascript" type="text/javascript" src="http://lib.sinaapp.com/js/jquery/1.4.2/jquery.min.js" ></script>
<script language="javascript" type="text/javascript" src="/include/ajax2.js"></script>

<div id="PageTopAD">
	<div id="PageTopAD1">
		<a target="_blank" id="PageTopAD1_link" href="http://www.eic.org.cn/special/20110506lyjyz/?utm_source=pagetop&utm_medium=www&utm_term=null&utm_content=pagetop&utm_campaign=201106"><img id="PageTopAD1_img" src="http://www.eic.org.cn/public/images/ztbg1.gif" /></a>
	</div>
	<div id="PageTopAD_close"><a href="javascript:closePageTopAD();">[ 关闭 X ]</a></div>
	<div id="PageTopAD2">
		<a target="_blank" id="PageTopAD2_link" href="http://www.eic.org.cn/special/20110506lyjyz/?utm_source=pagetop&utm_medium=www&utm_term=null&utm_content=pagetop&utm_campaign=201106"><img id="PageTopAD2_img" src="http://www.eic.org.cn/public/images/ztbg1.gif" /></a>
	</div>
</div>

<div id="top">

	<div class="top">
		<div class="xinleft">
			<a href="http://www.eic.org.cn/home/about.html" target="_blank" rel="nofollow">关于启德</a>|
			<a href="http://www.eic.org.cn/home/culture.html" target="_blank" rel="nofollow">启德文化</a>|
			<a href="http://partners.eic.org.cn/" target="_blank" rel="nofollow">Partner Services</a>
		</div>
		<!--
			<span  class="left padding3" id="login_right2" style="float:left">
				
					<input type="hidden" value="username" name="fastloginfield" id="fastloginfield"/>
					用户名：
					<input  type="text" class="input93" name="username" id="username"/>
					密  码：
					<input  type="password" class="input93" id="password" name="password"/>
					<input name="denglu" type="button" onclick="check_login()" value="登陆" class="button_1" />
					<input name="zhuce" type="button" value="注册" class="button_1" onclick="location.href='http://bbs.eic.org.cn/member.php?mod=xinzhuce';"/>
				
			</span>
	-->
		<p class="right padding3">
			<span>
				<input name="search_word" type="text" class="input173" id="search_word"/>
			</span>
			<span>
					<select name="select" class="input95" id="selType">
				<option value="0">院校类型</option>
				<option value='4'>大学</option>
				<option value='7'>学院</option>
				<option value='3'>中学</option>
				<option value='9'>社区学院</option>
				<option value='10'>语言学校</option>
				<option value='11'>预科</option>
				<option value='16'>社区大学</option>
				<option value='18'>教育区</option>
				<option value='20'>高等商学院</option>
				<option value='19'>理工学院</option>
				<option value='13'>延续教育学院</option>
				<option value='8'>职业技术学院</option>
				<option value='17'>酒店管理学院</option>
				<option value='14'>大学联盟</option>
				<option value='15'>教育集团</option>
				<option value='12'>其它</option>
				<option value="99">文章</option>
			</select>
			</span>
			<span>
				<input name="搜索" type="button" value="搜索" class="input46" id="search" onclick="searchCollege();"/>
			</span>
    </p>
	</div>
	<div class="newlogo">
		<span class="newlogo_a1"><a href="http://www.eic.org.cn" target="_blank"><img src="http://img0.eic.org.cn/public/images/logo0406.png" alt="启德教育"/></a></span>
		<span class="newlogo_a3">
			<ul>
				<li><a href="http://www.eic.org.cn/news/" target="_blank"><img src="http://img0.eic.org.cn/public/images/nav0406_1.gif" alt="留学新闻"/></a></li>
				<li><a href="http://train.eic.org.cn/" target="_blank"><img src="http://img0.eic.org.cn/public/images/nav0406_2.gif" alt="启德培训"/></a></li>
				<li><a href="http://college.eic.org.cn" target="_blank"><img src="http://img0.eic.org.cn/public/images/nav0406_3.gif"  alt="院校频道"/></a></li>
				<li><a href="http://studytour.eic.org.cn " target="_blank" ><img src="http://img0.eic.org.cn/public/images/nav0406_4.gif" alt="学游"/></a></li>
				
				<!--
				<li><a href="http://www.eic.org.cn/xueyou/" ><img src="http://img0.eic.org.cn/public/images/xindex_08.gif" alt="学游"/></a></li>-->
				<li><a href="http://www.eic.org.cn/case/" target="_blank"><img src="http://img0.eic.org.cn/public/images/nav0406_5.gif" alt="案例频道"/></a></li>
				<li><a href="http://www.eic.org.cn/blog/" target="_blank"><img src="http://img0.eic.org.cn/public/images/nav0406_6.gif" alt="博客频道"/></a></li>
				<li><a href="http://www.eic.org.cn/video/" target="_blank"><img src="http://img0.eic.org.cn/public/images/nav0406_8.gif" alt="视频频道"/></a></li>
				<li><a href="http://www.eic.org.cn/special/eic_hot_questions/" target="_blank"><img src="http://img0.eic.org.cn/public/images/nav0406_9.gif" alt="问答频道"/></a></li>
				<li><a href="http://www.studytown.cn/" target="_blank"><img src="http://img0.eic.org.cn/public/images/nav0406_10.jpg" alt="会员中心"/></a></li>
			</ul>
		</span>
		
		<!--免费咨询电话-->
		<div class="newlogo_a2">
			<h4><p>全国咨询热线</p><p>400-1010-123</p></h4>
            <span class="right">
            					<ul id="nav">
        			<li><a id="400hover" href="http://www.eic.org.cn/home/contact.html" target="_blank" onmouseover="mopen('info_nav_n')" onmouseout="mclosetime()"><img src="http://img0.eic.org.cn/public/images/xl.gif"/></a>
						<ul onmouseout="mclosetime()" onmouseover="mcancelclosetime()" id="info_nav_n" style="visibility: hidden;">
							          					<li class="fff">
								<a href="http://www.eic.org.cn/beijing" target="_blank">
								<b>北京</b>&nbsp;&nbsp;010-58781616&nbsp;&nbsp;&nbsp;</a><br>
							</li>
							
          					<li class="">
								<a href="http://www.eic.org.cn/beijing" target="_blank">
								<b>北京海淀</b>&nbsp;&nbsp;010-58362855&nbsp;</a>
							</li>
							
          					<li class="fff">
								<a href="http://www.eic.org.cn/shanghai" target="_blank">
								<b>上海</b>&nbsp;&nbsp;021-60328366&nbsp;&nbsp;&nbsp;</a>
							</li>
          					<li class="">
								<a href="http://www.eic.org.cn/guangzhou" target="_blank">
								<b>广州</b>&nbsp;&nbsp;020-22821688&nbsp;&nbsp;&nbsp;</a>
							</li>
          					<li class="">
								<a href="http://www.eic.org.cn/shenzhen" target="_blank">
								<b>深圳</b>&nbsp;&nbsp;0755-33330222&nbsp;&nbsp;</a>
							</li>
							<li class="">
								<a href="http://www.eic.org.cn/shenzhen" target="_blank">
								<b>汕头</b>&nbsp;&nbsp;0754-88818312&nbsp;&nbsp;</a>
							</li>
          					<li class="fff">
								<a href="http://www.eic.org.cn/jinan" target="_blank">
								<b>济南</b>&nbsp;&nbsp;0531-82960666&nbsp;&nbsp;</a>
							</li>
          					<li>
								<a href="http://www.eic.org.cn/shenyang" target="_blank">
								<b>沈阳</b>&nbsp;&nbsp;024-31877211&nbsp;&nbsp;&nbsp;</a>
							</li>
          					<li class="fff">
								<a href="http://www.eic.org.cn/qingdao" target="_blank">
								<b>青岛</b>&nbsp;&nbsp;0532-66776088&nbsp;&nbsp;</a>
							</li>
       			    		<li>
								<a href="http://www.eic.org.cn/nanjing" target="_blank">
								<b>南京</b>&nbsp;&nbsp;025-86993388&nbsp;&nbsp;&nbsp;</a>
							</li>
                    		<li class="fff">
								<a href="http://www.eic.org.cn/changsha" target="_blank">
								<b>长沙</b>&nbsp;&nbsp;0731-84488495&nbsp;&nbsp;</a>
							</li>
          					<li>
								<a href="http://www.eic.org.cn/xiamen" target="_blank">
								<b>厦门</b>&nbsp;&nbsp;0592-8126799&nbsp;&nbsp;&nbsp;</a>
							</li>
          					<li class="fff">
								<a href="http://www.eic.org.cn/wuhan" target="_blank">
								<b>武汉</b>&nbsp;&nbsp;027-82806941&nbsp;&nbsp;&nbsp;</a>
							</li>
							<li class="">
								<a href="http://www.eic.org.cn/wuhan" target="_blank">
								<b>武汉中商</b>&nbsp;&nbsp;027-87259300&nbsp;</a>
							</li>
          					<li class="fff">
								<a href="http://www.eic.org.cn/dalian" target="_blank">
								<b>大连</b>&nbsp;&nbsp;0411-82710101&nbsp;&nbsp;</a>
							</li>  
          					<li class="">
								<a href="http://www.eic.org.cn/chongqing" target="_blank">
								<b>重庆</b>&nbsp;&nbsp;023-86596776&nbsp;&nbsp;&nbsp;</a>
							</li>
          					<li class="fff">
								<a href="http://www.eic.org.cn/xian" target="_blank">
								<b>西安</b>&nbsp;&nbsp;029-88348605&nbsp;&nbsp;&nbsp;</a>
							</li>
          					<li class="">
								<a href="http://www.eic.org.cn/au" target="_blank">
								<b>澳洲</b>&nbsp;&nbsp;0061 292815000&nbsp;</a>
							</li>
       			    		<li class="fff">
								<a href="http://www.eic.org.cn/zhuhai" target="_blank">
								<b>珠海</b>&nbsp;&nbsp;0756-6126739&nbsp;&nbsp;&nbsp;</a>
							</li>
							<li class="">
								<a href="http://www.eic.org.cn/zhuhai" target="_blank">
								<b>珠海香洲</b>&nbsp;&nbsp;0756-2217882&nbsp;</a>
							</li>
							<li class="fff">
								<a href="http://www.eic.org.cn/zhuhai" target="_blank">
								<b>珠海香洲</b>&nbsp;&nbsp;0756-2217866&nbsp;</a>
							</li>
                    		<li class="">
								<a href="http://www.eic.org.cn/dongguan" target="_blank">
								<b>东莞</b>&nbsp;&nbsp;400-1010-123&nbsp;&nbsp;</a>
							</li>
                    		<li class="fff">
								<a href="http://www.eic.org.cn/zhongshan" target="_blank">
								<b>中山</b>&nbsp;&nbsp;0760-88386716&nbsp;&nbsp;</a>
							</li>
                    		<li class="">
								<a href="http://www.eic.org.cn/zhengzhou" target="_blank">
								<b>郑州</b>&nbsp;&nbsp;0371-55613266&nbsp;&nbsp;</a>
							</li>                   
          					<li class="fff">
								<a href="http://www.eic.org.cn/hangzhou" target="_blank">
								<b>杭州</b>&nbsp;&nbsp;0571-88028886&nbsp;&nbsp;</a>
							</li>
          					<li class="">
								<a href="http://www.eic.org.cn/ningbo" target="_blank">
								<b>宁波</b>&nbsp;&nbsp;0574-87235557&nbsp;&nbsp;</a>
							</li>
							<li class="">
								<a href="http://www.eic.org.cn/chengdu" target="_blank">
								<b>成都</b>&nbsp;&nbsp;028-86703008&nbsp;&nbsp;</a>
							</li>
						</ul>
                    </li>
       			</ul>
            </span>   		
		</div>
	</div>
</div>

<div class="neweicglobal" class="eicbg">
	<div class="logo_bottom">		
		<div class="xq" style="width:978px;">
			<div class="left"><b>我想去：</b></div>
			<ul>
				<li><a href="http://www.eic.org.cn/us/" title="美国留学" target="_blank">美国</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/uk/" title="英国留学" target="_blank"> 英国</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/au/" title="澳大利亚留学" target="_blank"> 澳洲</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/ca/" title="加拿大留学" target="_blank"> 加拿大</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/hk/" title="中国香港" target="_blank"> 中国香港</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/si/" title="新加坡留学" target="_blank"> 新加坡</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/ko/" title="韩国留学" target="_blank"> 韩国</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/nz/" title="新西兰留学" target="_blank"> 新西兰</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/ja/" title="日本留学" target="_blank"> 日本</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/fr/" title="法国留学" target="_blank"> 法国</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/ne/" title="荷兰留学" target="_blank"> 荷兰瑞士</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/ge/" title="德国奥地利留学" target="_blank"> 德国奥地利</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/NorthernEurope/" title="北欧留学" target="_blank">北 欧</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/ir/" title="爱尔兰留学" target="_blank"> 爱尔兰</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/ma/" title="马来西亚留学" target="_blank"> 马来西亚</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/sp/" title="西班牙留学" target="_blank"> 西班牙</a></li>
				<li class="b6b6b6">-</li>
				<li><a href="http://www.eic.org.cn/it/" title="意大利" target="_blank"> 意大利</a></li>	
			</ul>
		</div>
	</div>	
</div>
<div class="neweicglobal" class="eicbg">
	<div class="logo_bottom">
		<div class="left"> <b>我要读：</b>
		<a href="http://www.eic.org.cn/master/" title="申请硕士/申请博士" target="_blank">硕博</a>
		<a href="http://www.eic.org.cn/ba/" title="申请本科" target="_blank">本科</a>
		<a href="http://www.eic.org.cn/middle/" title="申请高中" target="_blank">高中</a> 
		&nbsp;&nbsp;
		</div>			
		<div class="left"> <b >我想学：</b>
		<a href="http://train.eic.org.cn/eic/IELTS/" target="_blank" title="雅思培训">雅思</a>
		<a href="http://train.eic.org.cn/eic/TOEFL/" target="_blank" title="托福培训">托福</a>
		<a href="http://train.eic.org.cn/eic/SAT/" target="_blank" title="SAT培训">SAT</a>
		<a href="http://train.eic.org.cn/special/ssat/" target="_blank" title="SSAT培训">SSAT</a>
		<a href="http://train.eic.org.cn/special/2013GRE/" target="_blank" title="GRE培训">GRE</a>
		<a href="http://train.eic.org.cn/eic/bkbd/tfbk/53479.html" target="_blank" title="GMAT培训">GMAT</a>
		<a href="http://train.eic.org.cn/eic/PTE/" target="_blank" title="PTE培训">PTE</a>
		<a href="http://train.eic.org.cn/eic/vip.html" target="_blank" title="VIP培训">VIP</a>
		<a href="http://train.eic.org.cn/eic/language/" target="_blank" title="小语种">小语种</a>
		<a href="http://train.eic.org.cn/ChooseClass/Search.php?sid=&date=undefinedundefined&did=385&dt=undefined&date=undefinedundefined&pmin=0&pmax=0&did=389&attr=undefined" target="_blank" title="综合">综合</a>
		<a href="http://www.eic.org.cn/special/foundation/" target="_blank" title="国际预科">国际预科</a>
		</div>
	</div>	
</div>


<!--启德全球-->
<div class="neweicglobal">
	<ul>  
		<li class="bold size12 Padr10"><a href="http://www.eic.org.cn" target="_blank">启德全球</a>：</li>
		<li><a href="http://www.eic.org.cn/beijing/" title="启德北京" target="_blank">北京</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/shanghai/" title="启德上海" target="_blank">上海</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/guangzhou/" title="启德广州" target="_blank">广州</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/shenzhen/" title="启德深圳" target="_blank">深圳</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/wuhan/" title="启德武汉" target="_blank">武汉</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/changsha/" title="启德长沙" target="_blank">长沙</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/nanjing/" title="启德南京" target="_blank">南京</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/jinan/" title="启德济南" target="_blank">济南</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/qingdao/" title="启德青岛" target="_blank">青岛</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/xiamen/" title="启德厦门" target="_blank">厦门</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/dalian/" title="启德大连" target="_blank">大连</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/shenyang/" title="启德沈阳" target="_blank">沈阳</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/chongqing/" title="启德重庆" target="_blank">重庆</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/xian/" title="启德西安" target="_blank">西安</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/zhengzhou/" title="启德郑州" target="_blank">郑州</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/hangzhou/" title="启德杭州" target="_blank">杭州</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/ningbo/" title="启德宁波" target="_blank">宁波</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/chengdu/" title="启德成都" target="_blank">成都</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/zhuhai/" title="启德珠海" target="_blank">珠海</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/dongguan/" title="启德东莞" target="_blank">东莞</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/zhongshan/" title="启德中山" target="_blank">中山</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/shantou/" title="启德汕头" target="_blank">汕头</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/tianjin/" title="启德天津" target="_blank">天津</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/fuzhou/" title="启德福州" target="_blank">福州</a></li>
		<li class="b6b6b6">-</li>
		<li><a href="http://www.eic.org.cn/sydney/" title="启德澳洲" target="_blank">澳洲</a></li>
		<li class="b6b6b6">-</li>
		<li><a style="font-size:10px;" href="http://partners.eic.org.cn/" title="Partner Services" target="_blank" rel="nofollow">Partner Services</a></li>
	</ul>
</div>

<!--第一行内容-->

<script language=javascript type=text/javascript src="/public/js/home.js"></script>
<!-- header end -->


<style>
.centent {
	width: 960px;
	margin: 0px auto;	
}

.centent404 {
	height: 450px;
	width: 958px;
	border: 1px solid #dedede;
	margin-top: 10px;
}
.centent404n {
	background-image: url(../images/404.png);
	background-repeat: no-repeat;
	height: 232px;
	width: 460px;
	margin-top: 65px;
	margin-right: auto;
	margin-bottom: auto;
	margin-left: auto;
	padding-top: 30px;
	padding-left: 198px;
	text-align: left;
}
.centent404n ul li {
	list-style-type:none;
}
.centent404n1 {
	font-family: "微软雅黑";
	font-size: 32px;
	color: #fe4f32;
}
.centent404n2 {
	font-family: "微软雅黑";
	font-size: 18px;
	_height:18px;
	color: #000;
}
.centent404n3 {
	color: #005bac;
	line-height: 25px;
	height:25px;
	width:440px;
	border:1px solid #adcce9;
	padding-left:10px;
	margin:5px 0;
}
.centent404n4 {
	line-height: 24px;
	color: #000;
}
.centent404n4 a {
	color: #005bac;
}

</style>


<!--主题内容开始-->
<div class="centent" id="centent404">
	<div class="centent404">
   	  <div class="centent404n">
      <ul>
        	<li class="centent404n1">出错了！</li>
          	<li class="centent404n2">很抱歉，您要访问的页面暂时不能显示。</li>
            <li class="centent404n3">哦？这里还没有人来过哦，运气不错！</li>
        <li class="centent404n4">您正在浏览的页面可能已被删除、重命名或暂时不可用，您可以试一试以下几种方法：<br />
        1、检查网址是否正确。<br />
        2、直接访问<a href="/">启德留学首页</a>。<br />
        </li></ul></div>
    </div>
</div>
<!--主题内容结束-->



<!-- footer start -->
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
<style type="text/css">
body{margin:0 auto;padding:0}
.specialty ul,.specialty ul,.specialty ol,.specialty li,specialty div{margin:0;}
.specialty ul,.specialty ol,.specialty li{list-style:none;}
.specialty a{color:#000; text-decoration:none;}
.specialty a:hover{color:#666;}
.specialty{font-size:12px; font-family:"宋体","微软雅黑","黑体";width:998px; margin:0 auto;border:1px solid #ddd; clear:both; overflow:hidden; background-color:#fff;padding:0;margin-bottom:10px}
.specialty_tit{background:url(http://img0.eic.org.cn/public/images/fw_bg.png) repeat-x; height:34px;padding-left:15px; line-height:34p
x;color:#4b5464; font-family:"微软雅黑","黑体","宋体";}
.specialty_tit .a1{ font-size:18px; font-weight:700; padding-right:5px;}.specialty_tit .a2{ font-size:14px; font-weight:700;}
.specialty_list{padding:10px 0 0 15px;width:983px; overflow:hidden; padding-bottom:10px;}
.specialty_list li{ float:left; width:152px; margin-right:8px; line-height:26px; height:26px; }

/*版权*/
.footer p{line-height:0px; padding:0;margin:0; font-family:"宋体","微软雅黑","黑体";}
.footer{margin:0;padding:0;font-size:12px;text-align:center;line-height:22px;width:1000px;margin:0 auto;color:#787878; border-top:1px solid #ddd; padding-top:5px;}/*height:70px;*/
.footer a{color:#787878;}
.footer img{border:0;}
</style>
<div class="specialty" id="id14">
	<div class="specialty_tit">
    	<span class="a1">专业留学服务</span><span class="a2">欢迎联系启德顾问</span><span style="margin-left:550px;font-weight:bold;font-size:14px">咨询热线：<span style="color:red">400-1010-123</span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
    </div>
    	<style>
body{margin:0;padding:0}
ul,li{list-style:none outside none;text-decoration:none; margin:0; padding:0;}
.specialty_list{width:983px;overflow:hidden;font-size:12px;padding:10px 0 10px 15px;}
.specialty_list li{ float:left;width:152px;margin-right:8px;line-height:26px; height:26px;font-family: "宋体","微软雅黑","黑体";}
.specialty_list a{color:#000;text-decoration:none;}
.specialty_list a:hover{color:#666;}
</style>
<script language="javascript">document.domain = 'eic.org.cn';</script>
<ul class="specialty_list">
	<li>
		<a href="http://www.eic.org.cn/beijing" target="_blank">
		<b>启德北京</b>  010-58781616</a><br>
	</li>							
	<li>
		<a href="http://www.eic.org.cn/beijing" target="_blank">
		<b>北京海淀</b>  010-58362855</a>
	</li>							
	<li>
		<a href="http://www.eic.org.cn/shanghai" target="_blank">
		<b>启德上海</b>  021-60328366</a>
	</li>
	<li >
		<a href="http://www.eic.org.cn/guangzhou" target="_blank">
		<b>启德广州</b>  020-22821688</a>
	</li>
	<li >
		<a href="http://www.eic.org.cn/guangzhou" target="_blank">
		<b>广州越秀</b>  020-83186599</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/shenzhen" target="_blank">
		<b>启德深圳</b>  0755-33330222</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/jinan" target="_blank">
		<b>启德济南</b>  0531-82960666</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/shenyang" target="_blank">
		<b>启德沈阳</b>  024-31877211</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/qingdao" target="_blank">
		<b>启德青岛</b>  0532-66776088</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/nanjing" target="_blank">
		<b>启德南京</b>  025-86993388</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/changsha" target="_blank">
		<b>启德长沙</b>  0731-84488495</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/xiamen" target="_blank">
		<b>启德厦门</b>  0592-8126799</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/wuhan" target="_blank">
		<b>武汉汉口</b>  027-82806941</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/wuhan" target="_blank">
		<b>武汉武昌</b>  027-87259300</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/dalian" target="_blank">
		<b>启德大连</b>  0411-82710101</a>
	</li>  
	<li>
		<a href="http://www.eic.org.cn/chongqing" target="_blank">
		<b>启德重庆</b>  023-86596776</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/xian" target="_blank">
		<b>启德西安</b>  029-88348605</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/zhuhai" target="_blank">
		<b>启德珠海</b>  0756-6126739</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/zhuhai" target="_blank">
		<b>珠海香洲</b>  0756-2217882</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/zhuhai" target="_blank">
		<b>珠海香洲</b>  0756-2217866</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/dongguan" target="_blank">
		<b>启德东莞</b>  0769-23194131</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/zhongshan" target="_blank">
		<b>启德中山</b>  0760-88386716</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/zhengzhou" target="_blank">
		<b>启德郑州</b>  0371-55613266</a>
	</li>                   
	<li>
		<a href="http://www.eic.org.cn/hangzhou" target="_blank">
		<b>启德杭州</b>  0571-88028886</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/ningbo" target="_blank">
		<b>启德宁波</b>  0574-87235557</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/chengdu" target="_blank">
		<b>启德成都</b>  028-86703008</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/shantou" target="_blank">
		<b>启德汕头</b>  0754-88818312</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/tianjin" target="_blank">
		<b>启德天津</b>  022-58520899</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/au" target="_blank">
		<b>启德澳洲</b>  0061-292815000</a>
	</li>
	<li>
		<a href="http://www.eic.org.cn/fuzhou" target="_blank">
		<b>启德福州</b>  0591-87890330</a>
	</li>
</ul>
	<div style="clear:both"></div>
</div>
<div class="footer" id="id15">  
	<a href="http://www.eic.org.cn/home/about.html" target='_blank' rel="nofollow">关于启德</a>&nbsp;|&nbsp;
<a href="http://www.eic.org.cn/home/culture.html" target='_blank' rel="nofollow">启德文化</a>&nbsp;|&nbsp;
<a href="http://www.eic.org.cn/home/Cooperation.html" target='_blank' rel="nofollow">市场合作</a>&nbsp;|&nbsp;
<a href="http://www.eic.org.cn/home/opinion.html" target='_blank' rel="nofollow">客户投诉</a>&nbsp;|&nbsp;
<a href="http://www.eic.org.cn/home/contact.html" target='_blank' rel="nofollow">联系我们</a>&nbsp;|&nbsp;
<a href="http://www.eic.org.cn/f/flink.php" target='_blank' rel="nofollow">友情链接</a>&nbsp;|&nbsp;
<a href="http://www.eic.org.cn/blog/" target='_blank' rel="nofollow">顾问博客</a>&nbsp;|&nbsp;
<a href="http://www.eic.org.cn/f/join.php" target='_blank' rel="nofollow">在线招聘</a>&nbsp;|&nbsp;
<a href="/rss/sitemap.html" target='_blank' rel="nofollow">网站地图</a>&nbsp;|&nbsp;
<a href="http://partners.eic.org.cn/" target='_blank' rel="nofollow">English</a>

<br />
    Copyright © 2003-2014 EIC<!-- 启德教育集团 --> 启德教育 www.eic.org.cn All Rights Reserved<br />
    京ICP证110879号 京ICP备11006015号-3  京公网安备110105009096
	<p >
		<a onmousedown="hits('bot06');" target="_blank" href="http://www.bj.cyberpolice.cn/index.htm">
			<img alt="北京网络警察报警平台" src="http://img0.eic.org.cn/public/images/fl1.gif"></a> 
		<img alt="公共信息安全网络监察" src="http://img0.eic.org.cn/public/images/fl2.gif"> 
		<a onmousedown="hits('bot06');" target="_blank" href="http://www.miibeian.gov.cn/">
			<img alt="经营性网站备案信息" src="http://img0.eic.org.cn/public/images/fl3.gif"></a> 
		<a onmousedown="hits('bot06');" target="_blank" href="http://net.china.com.cn/index.htm">
			<img alt="不良信息举报中心" src="http://img0.eic.org.cn/public/images/fl4.gif"></a> 
		<img alt="中国文明网传播文明" src="http://img0.eic.org.cn/public/images/fl5.gif">
		<!--可信网站图片LOGO安装开始-->
		<script src="https://ss.cnnic.cn/seallogo.dll?sn=e12010411010008381307708&size=0"></script>
		<!--可信网站图片LOGO安装结束-->
	</p>
</div>



</body>
</html>

<script type='text/javascript' src='http://www.eic.org.cn/public/js/analytics.js'></script>


<!-- footer end -->
</body>
</html>
